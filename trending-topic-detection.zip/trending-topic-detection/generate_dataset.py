"""Generate a synthetic social-media (tweet-like) dataset with injected trending bursts.
Output: data/tweets.csv  (timestamp, user, text)
You can replace this file with a real dataset that has the same columns."""
import random, csv
from datetime import datetime, timedelta

random.seed(42)
START = datetime(2026, 10, 17, 0, 0)
HOURS = 7 * 24

BACKGROUND = [
    "Good morning everyone, coffee time #coffee",
    "Traffic is terrible today again #traffic",
    "Just watched a great movie last night #movies",
    "Studying for exams, send help #college",
    "Love this weather today #weather",
    "New phone is amazing so far #tech",
    "Anyone has good biryani places to recommend #food",
    "Working from home is the best #wfh",
    "Cricket practice in the evening #cricket",
    "Listening to old songs on repeat #music",
    "Gym session done, feeling strong #fitness",
    "Reading a really good book this weekend #books",
]
# (hashtag, sentence templates, start hour, duration, peak tweets/hour)
EVENTS = [
    ("#DiwaliSale", ["Huge {t} offers live now, discounts up to 70 percent", "Cannot miss the {t} deals on phones and laptops",
                     "{t} is crazy this year, cart is full"], 48, 30, 70),
    ("#IndiaVsAus", ["What a match! {t} going down to the last over", "{t} Kohli smashes a century, stadium erupts",
                     "Unbelievable bowling in {t} tonight"], 100, 10, 120),
    ("#AIRegulation", ["Government announces new framework, {t} debate begins", "Experts discuss {t} and its impact on startups",
                       "Is {t} going to slow down innovation?"], 130, 24, 55),
    ("#CycloneAlert", ["Heavy rain warning issued, {t} stay safe everyone", "{t} coastal areas evacuated, helplines active",
                       "Please share verified updates on {t}"], 20, 14, 90),
]
rows = []
for h in range(HOURS):
    ts_hour = START + timedelta(hours=h)
    n_bg = max(5, int(random.gauss(25, 4)))  # baseline traffic (more by day)
    if 8 <= ts_hour.hour <= 22: n_bg += 10
    for _ in range(n_bg):
        rows.append((ts_hour + timedelta(minutes=random.randint(0, 59), seconds=random.randint(0, 59)),
                     f"user{random.randint(1, 800)}", random.choice(BACKGROUND)))
    for tag, templates, start, dur, peak in EVENTS:
        if start <= h < start + dur:
            x = (h - start) / dur                       # rise-and-decay profile
            intensity = peak * (4 * x * (1 - x)) + random.randint(0, 5)
            for _ in range(int(intensity)):
                rows.append((ts_hour + timedelta(minutes=random.randint(0, 59), seconds=random.randint(0, 59)),
                             f"user{random.randint(1, 800)}", random.choice(templates).format(t=tag)))
        elif random.random() < 0.15:                    # tiny pre-event noise
            rows.append((ts_hour + timedelta(minutes=random.randint(0, 59)), f"user{random.randint(1,800)}",
                         f"thinking about {tag}"))
random.shuffle(rows); rows.sort(key=lambda r: r[0])
with open("data/tweets.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["timestamp", "user", "text"])
    for ts, u, t in rows: w.writerow([ts.strftime("%Y-%m-%d %H:%M:%S"), u, t])
print(f"Generated {len(rows)} tweets -> data/tweets.csv")
