"""
Trending Topic Detection on Social Media
----------------------------------------
Pipeline:
 1. Load tweets (timestamp, text)
 2. Clean text  -> lowercase, strip URLs/mentions/punctuation, remove stopwords
 3. Extract terms -> hashtags + unigrams + bigrams
 4. Build hourly time-series per term
 5. Burst detection -> z-score of current hour vs. rolling baseline of previous 24h
 6. Rank terms by trend score, save report + charts
 7. (Bonus) Group tweets into topics with TF-IDF + KMeans

Usage:  python trend_detector.py [--input data/tweets.csv] [--top 10] [--window 24]
"""
import argparse, re, os
from collections import Counter, defaultdict
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans

STOPWORDS = set("""a an the and or but if in on at to for of is are was were be been am i you he she it we they this that
these those my your our their me him her us them with as by from so just not no yes do does did have has had will would can
could should about into over than then there here what when who how why which all any some more most very too also again
today tonight now still really get got going go one""".split())


def clean(text):
    text = re.sub(r"http\S+|@\w+", " ", text.lower())
    text = re.sub(r"[^a-z0-9#\s]", " ", text)
    return text


def extract_terms(text):
    tokens = [t for t in clean(text).split() if t not in STOPWORDS and len(t) > 2]
    terms = [t for t in tokens if t.startswith("#")]                       # hashtags
    words = [t for t in tokens if not t.startswith("#")]
    terms += words                                                          # unigrams
    terms += [f"{a} {b}" for a, b in zip(words, words[1:])]                 # bigrams
    return set(terms)  # a term counts once per tweet


def build_timeseries(df):
    counts = defaultdict(Counter)
    for ts, text in zip(df["hour"], df["text"]):
        for term in extract_terms(text):
            counts[term][ts] += 1
    hours = pd.date_range(df["hour"].min(), df["hour"].max(), freq="h")
    ts = pd.DataFrame({t: pd.Series(c) for t, c in counts.items()}).reindex(hours).fillna(0)
    return ts


def burst_scores(ts, window=24, min_count=10):
    """z-score of each hour against the mean/std of the previous `window` hours."""
    base_mean = ts.rolling(window, min_periods=6).mean().shift(1)
    base_std = ts.rolling(window, min_periods=6).std().shift(1)
    z = (ts - base_mean) / (base_std + 1.0)           # +1 smoothing avoids divide-by-zero for rare terms
    z = z.where(ts >= min_count, 0)                   # ignore tiny volumes
    return z.fillna(0)


def rank_trends(ts, z, top=10, hashtags=True):
    """Rank bursty terms. hashtags=True -> only #tags, False -> only plain keywords/bigrams."""
    keep = [c for c in ts.columns if c.startswith("#") == hashtags]
    ts, z = ts[keep], z[keep]
    peak_hour = z.idxmax()
    rows = []
    for term in ts.columns:
        if z[term].max() <= 3:  # not a burst
            continue
        rows.append({"topic": term, "trend_score": round(z[term].max(), 2), "peak_time": peak_hour[term],
                     "peak_volume": int(ts[term].max()), "total_mentions": int(ts[term].sum())})
    res = pd.DataFrame(rows).sort_values("trend_score", ascending=False)
    # prefer hashtags & drop terms that are sub-phrases of a better ranked trend
    return res.head(top).reset_index(drop=True)


def related_keywords(df, tag, n=4):
    """Words that most often co-occur with a trending hashtag (explains *what* the trend is about)."""
    c = Counter()
    for text in df.loc[df["text"].str.lower().str.contains(tag), "text"]:
        c.update(t for t in extract_terms(text) if not t.startswith("#") and " " not in t)
    return ", ".join(w for w, _ in c.most_common(n))


def plot_trends(ts, report, out="outputs/trend_timeline.png"):
    plt.figure(figsize=(11, 5))
    for term in report["topic"][:5]:
        plt.plot(ts.index, ts[term], label=term, linewidth=2)
    plt.title("Hourly mention volume of detected trending topics"); plt.xlabel("Time"); plt.ylabel("Mentions / hour")
    plt.legend(); plt.grid(alpha=.3); plt.tight_layout(); plt.savefig(out, dpi=150); plt.close()

    plt.figure(figsize=(9, 5))
    r = report.iloc[::-1]
    plt.barh(r["topic"], r["trend_score"], color="#2563eb")
    plt.title("Top trending topics (burst z-score)"); plt.xlabel("Trend score"); plt.tight_layout()
    plt.savefig("outputs/top_trends.png", dpi=150); plt.close()


def cluster_topics(df, k=8):
    """Bonus: unsupervised topic grouping of tweets with TF-IDF + KMeans."""
    docs = df["text"].map(lambda t: " ".join(w for w in clean(t).split() if w not in STOPWORDS))
    vec = TfidfVectorizer(max_features=3000, ngram_range=(1, 2))
    X = vec.fit_transform(docs)
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X)
    terms = np.array(vec.get_feature_names_out())
    out = []
    for c in range(k):
        top = terms[np.argsort(km.cluster_centers_[c])[::-1][:5]]
        out.append({"cluster": c, "tweets": int((km.labels_ == c).sum()), "keywords": ", ".join(top)})
    return pd.DataFrame(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/tweets.csv")
    ap.add_argument("--top", type=int, default=10)
    ap.add_argument("--window", type=int, default=24)
    a = ap.parse_args()

    os.makedirs("outputs", exist_ok=True)
    df = pd.read_csv(a.input, parse_dates=["timestamp"])
    df["hour"] = df["timestamp"].dt.floor("h")
    print(f"Loaded {len(df)} tweets from {df['timestamp'].min()} to {df['timestamp'].max()}")

    ts = build_timeseries(df)
    z = burst_scores(ts, a.window)
    report = rank_trends(ts, z, a.top, hashtags=True)
    report["related_keywords"] = [related_keywords(df, t) for t in report["topic"]]
    print("\n=== TRENDING HASHTAGS ===")
    print(report.to_string(index=False))
    report.to_csv("outputs/trending_report.csv", index=False)
    plot_trends(ts, report)

    kw = rank_trends(ts, z, a.top, hashtags=False)
    print("\n=== TRENDING KEYWORDS (non-hashtag) ===")
    print(kw.to_string(index=False))
    kw.to_csv("outputs/trending_keywords.csv", index=False)

    clusters = cluster_topics(df)
    print("\n=== TOPIC CLUSTERS (TF-IDF + KMeans) ===")
    print(clusters.to_string(index=False))
    clusters.to_csv("outputs/topic_clusters.csv", index=False)
    print("\nSaved: outputs/trending_report.csv, trending_keywords.csv, topic_clusters.csv, trend_timeline.png, top_trends.png")


if __name__ == "__main__":
    main()
